#ifndef FIFO_H
#define FIFO_H

#include "lista.h"

int fifo(list *logicas, int npf);

#endif