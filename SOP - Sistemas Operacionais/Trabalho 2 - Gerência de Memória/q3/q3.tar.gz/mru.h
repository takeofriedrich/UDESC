#ifndef MRU_H
#define MRU_H
#include "stdio.h"
#include "lista.h"

void* imprimeLong2(void *valor);
int mru(list *logicas, int npf);

#endif